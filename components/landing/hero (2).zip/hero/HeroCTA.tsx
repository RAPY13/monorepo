"use client";

import Link from "next/link";
import { ArrowRight, Mail } from "lucide-react";

export default function HeroCTA() {
  return (
    <div
      data-hero="cta"
      className="mx-auto mt-14 flex w-full max-w-2xl flex-col items-center"
    >
      {/* Join Card */}
      <div
        className="
          w-full
          rounded-3xl
          border
          border-white/10
          bg-white/[0.03]
          p-6
          backdrop-blur-2xl
          shadow-[0_20px_60px_rgba(0,0,0,.45)]
          transition-all
          duration-300
          hover:border-[#5B7FFF]/30
          hover:shadow-[0_0_45px_rgba(91,127,255,.12)]
          md:p-8
        "
      >
        <h3
          className="
            text-center
            text-xl
            font-bold
            uppercase
            tracking-[0.28em]
            text-white
          "
        >
          ENTER THE YARD
        </h3>

        <p
          className="
            mt-5
            text-center
            text-base
            leading-8
            text-slate-300
          "
        >
          Built for the Culture.
        </p>

        <p
          className="
            mt-2
            text-center
            text-sm
            leading-7
            text-slate-400
          "
        >
          Where music brings people together.
        </p>

        {/* Magic Link Preview */}
        <div
          className="
            mt-8
            rounded-2xl
            border
            border-white/10
            bg-black/40
            p-5
          "
        >
          <div
            className="
              flex
              items-center
              gap-3
              rounded-xl
              border
              border-white/10
              bg-white/[0.03]
              px-4
              py-4
              text-slate-500
            "
          >
            <Mail size={18} className="text-[#5B7FFF]" />
            <span className="text-sm">
              Enter your email to receive a secure Magic Link
            </span>
          </div>

          <p
            className="
              mt-4
              text-center
              text-xs
              uppercase
              tracking-[0.22em]
              text-slate-500
            "
          >
            Secure Magic Link • No Password Required
          </p>
        </div>
      </div>

      {/* Primary CTA */}
      <Link
        href="/gate"
        className="
          group
          mt-8
          inline-flex
          items-center
          gap-3
          rounded-full
          border
          border-[#5B7FFF]
          bg-[#5B7FFF]
          px-8
          py-4
          text-sm
          font-bold
          uppercase
          tracking-[0.25em]
          text-white
          transition-all
          duration-300
          hover:-translate-y-1
          hover:scale-[1.02]
          hover:bg-[#6F8CFF]
          hover:border-[#6F8CFF]
          hover:shadow-[0_0_30px_rgba(91,127,255,.35)]
          active:scale-95
        "
      >
        <span>Enter The Yard</span>

        <ArrowRight
          size={18}
          className="transition-transform duration-300 group-hover:translate-x-1"
        />
      </Link>

      {/* Trust Statement */}
      <p
        className="
          mt-6
          max-w-xl
          text-center
          text-sm
          leading-7
          text-slate-500
        "
      >
        Record, collaborate, compete, and build your community—all in one place.
        Your account is secured with passwordless Magic Link authentication.
      </p>
    </div>
  );
}